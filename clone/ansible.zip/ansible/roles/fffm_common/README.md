fffm_common
===========

Carry out some automation tasks, that I want to be done on every host. This includes mainly installing some packages, which I regularly use.

Role Variables
--------------

- fffm_common_packages: A list of packages defined in defaults/main.yml, that will be installed.

Author Information
------------------

felix dot schulthess at zeiss dot com
